<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VSOFT (http://vsoft.com.vn)
 * @Copyright (C) 2019 VSOFT. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Mon, 24 Jun 2019 03:19:55 GMT
 */

if ( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

$module_version = array(
		'name' => 'Del-2module-link',
		'modfuncs' => '',
		'submenu' => '',
		'is_sysmod' => 0,
		'virtual' => 1,
		'version' => '4.3.6',
		'date' => 'Mon, 24 Jun 2019 03:19:55 GMT',
		'author' => 'VSOFT (vsoft.com.vn)',
		'uploads_dir' => array($module_name),
		'note' => ''
	);