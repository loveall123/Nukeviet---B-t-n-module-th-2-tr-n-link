<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VSOFT (http://vsoft.com.vn)
 * @Copyright (C) 2019 VSOFT. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Mon, 24 Jun 2019 03:19:55 GMT
 */

if ( ! defined( 'NV_MAINFILE' ) ) die( 'Stop!!!' );

$lang_translator['author'] = 'VSOFT (vsoft.com.vn)';
$lang_translator['createdate'] = '24/06/2019, 03:19';
$lang_translator['copyright'] = '@Copyright (C) 2019 VSOFT. All rights reserved';
$lang_translator['info'] = '';
$lang_translator['langtype'] = 'lang_module';

$lang_module['main'] = 'Cấu hình xóa tên module trên link';
$lang_module['submit'] = 'Lưu lại';
$lang_module['module_del'] = 'Chọn module cần xóa link';
$lang_module['no_selected'] = 'Không chọn';