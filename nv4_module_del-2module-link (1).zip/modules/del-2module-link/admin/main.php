<?php

/**
 * @Project NUKEVIET 4.x
 * @Author VSOFT (http://vsoft.com.vn)
 * @Copyright (C) 2019 VSOFT. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Mon, 24 Jun 2019 03:19:55 GMT
 */

if ( ! defined( 'NV_IS_FILE_ADMIN' ) )
    die( 'Stop!!!' );

$data = ! empty( $module_config[$module_name] ) ? $module_config[$module_name] : array();
$array_data = array();

foreach ( $site_mods as $key => $value )
{
    if ( in_array( $value['module_file'], array( 'news', 'shops' ) ) and $key != $global_config['rewrite_op_mod'] )
    {
        $array_data[$key] = $value['custom_title'];
    }
}

if ( $nv_Request->isset_request( "submit", "post" ) )
{
    $data['module_del'] = $nv_Request->get_title( 'module_del', 'post', '' );

    $sql = "DELETE FROM " . NV_CONFIG_GLOBALTABLE . " WHERE module=" . $db->quote( $module_name );
    $db->query( $sql );

    foreach ( $data as $config_name => $config_value )
    {
        $db->query( "INSERT INTO " . NV_CONFIG_GLOBALTABLE . " (lang, module, config_name, config_value) VALUES('" . NV_LANG_DATA . "', " . $db->quote( $module_name ) . ", " . $db->quote( $config_name ) . ", " . $db->quote( $config_value ) . ")" );
    }
    
    $link_storecode = NV_ROOTDIR . '/modules/' . $module_file . '/store.code.txt';
    
    $link_fopen = fopen( $link_storecode, "r" ) or die( "Unable to open file!" );
    $storecode = fread( $link_fopen, filesize( $link_storecode ) );

    //luu lai config
    $file_contents = "<?php\n\n";
    $file_contents .= "\$module_del = '" . $data['module_del'] . "';\n";
    $file_contents .= $storecode;
    $file_contents .= "\n?>";
    
    fclose( $link_fopen );

    file_put_contents( NV_ROOTDIR . '/del_2module_link.php', $file_contents, LOCK_EX );

    $nv_Cache->delMod( $module_name );
    $nv_Cache->delMod( 'settings' );

    nv_insert_logs( NV_LANG_DATA, $module_name, $lang_module['main'], "", $admin_info['userid'] );
    Header( "Location: " . NV_BASE_ADMINURL . "index.php?" . NV_LANG_VARIABLE . "=" . NV_LANG_DATA . "&" . NV_NAME_VARIABLE . "=" . $module_name );
    die();
}

$link_introduction = NV_ROOTDIR . '/modules/' . $module_file . '/introduction.txt';
    
$link_fopen = fopen( $link_introduction, "r" ) or die( "Unable to open file!" );
$introduction = fread( $link_fopen, filesize( $link_introduction ) );

$xtpl = new XTemplate( $op . '.tpl', NV_ROOTDIR . '/themes/' . $global_config['module_theme'] . '/modules/' . $module_file );
$xtpl->assign( 'LANG', $lang_module );
$xtpl->assign( 'NV_LANG_VARIABLE', NV_LANG_VARIABLE );
$xtpl->assign( 'NV_LANG_DATA', NV_LANG_DATA );
$xtpl->assign( 'NV_BASE_ADMINURL', NV_BASE_ADMINURL );
$xtpl->assign( 'NV_NAME_VARIABLE', NV_NAME_VARIABLE );
$xtpl->assign( 'NV_OP_VARIABLE', NV_OP_VARIABLE );
$xtpl->assign( 'MODULE_NAME', $module_name );
$xtpl->assign( 'OP', $op );
$xtpl->assign( 'introduction', $introduction );

fclose( $link_fopen );

if ( ! empty( $array_data ) )
{
    foreach ( $array_data as $key => $value )
    {
        $xtpl->assign( 'TITLE', $value );
        $xtpl->assign( 'KEY', $key );
        $xtpl->assign( 'SELECTED', ( ! empty( $data['module_del'] ) and $data['module_del'] == $key ) ? ' selected="selected"' : '' );

        $xtpl->parse( 'main.loop' );
    }
}

$xtpl->parse( 'main' );
$contents = $xtpl->text( 'main' );

$page_title = $lang_module['main'];

include NV_ROOTDIR . '/includes/header.php';
echo nv_admin_theme( $contents );
include NV_ROOTDIR . '/includes/footer.php';

?>